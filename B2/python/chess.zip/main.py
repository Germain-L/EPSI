import chess


if __name__ == '__main__':
    my_board = chess.Chess()
    my_board.display()
